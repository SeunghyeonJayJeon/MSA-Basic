package google.drive.dto.entity;

import java.util.Date;
import lombok.Data;
@Data
public class Index{
    private Long id;
    private Long fileId;

    
}