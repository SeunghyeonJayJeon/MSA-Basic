# python

1. install dependencies 
```
pip3 install -r requirements 
```

2. run application 
```
python3 app.py
```