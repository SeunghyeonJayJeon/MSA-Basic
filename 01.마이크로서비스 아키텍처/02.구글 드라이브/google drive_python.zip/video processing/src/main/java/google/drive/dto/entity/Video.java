package google.drive.dto.entity;

import java.util.Date;
import lombok.Data;
@Data
public class Video{
    private Long id;
    private Long fileId;
    private String url;

    
}