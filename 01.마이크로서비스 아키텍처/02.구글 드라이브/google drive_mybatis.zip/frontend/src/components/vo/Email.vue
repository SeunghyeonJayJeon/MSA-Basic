<template>
    <div>
        <v-card style="width:300px; margin-left:5%;" outlined>
            
            <v-card-title>
                Email
            </v-card-title>
            <v-card-text style = "margin-left:-15px; margin-top:10px;">
                <div class="grey--text ml-4" v-if="editMode" style = "margin-top:-20px;">
                    <v-text-field label="Address" v-model="value.address"/>
                </div>
                <div class="grey--text ml-4" v-else>
                    Address :  
                </div>
                <div class="grey--text ml-4" v-if="editMode" style = "margin-top:-20px;">
                    <v-text-field label="Subject" v-model="value.subject"/>
                </div>
                <div class="grey--text ml-4" v-else>
                    Subject :  
                </div>
                <div class="grey--text ml-4" v-if="editMode" style = "margin-top:-20px;">
                    <v-text-field label="Content" v-model="value.content"/>
                </div>
                <div class="grey--text ml-4" v-else>
                    Content :  
                </div>
            </v-card-text>
        
        </v-card>
    </div>
</template>

<script>
export default {
    name:"Email",
    props: {
        editMode: Boolean,
        value : Object,
    },


    data: () => ({
        date: new Date().toISOString().substr(0, 10),
    }),
    
    
}
</script>

<style scoped>
    .address-v-card-title {
        display: contents;
    }
    .address-v-text-field {
        margin-top:5px;
    }
</style>