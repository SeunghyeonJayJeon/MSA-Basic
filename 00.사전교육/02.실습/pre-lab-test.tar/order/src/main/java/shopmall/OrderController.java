package shopmall;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

}
